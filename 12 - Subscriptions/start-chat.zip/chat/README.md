# GraphQL Chat

This is a project used in the [GraphQL by Example](https://www.udemy.com/course/graphql-by-example/?referralCode=7ACEB04674F000BAC061) course.

It shows how to use subscriptions with Apollo Server for Express, Apollo Client, and GraphQL-WS.
