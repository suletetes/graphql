# GraphQL Hello World

This is a project used in the [GraphQL by Example](https://www.udemy.com/course/graphql-by-example/?referralCode=7ACEB04674F000BAC061) course.

It uses Apollo Server to expose a minimal GraphQL API, and a web page with vanilla JavaScript as the client.
